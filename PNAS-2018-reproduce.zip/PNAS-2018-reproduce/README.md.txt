# PNAS 2018 论文可复现性评估与复现
**论文题目**：Cell-to-cell bacterial interactions promoted by drier conditions on soil surfaces

## 基本信息
- 论文DOI：10.1073/pnas.1808274115
- 原文地址：https://www.pnas.org/cgi/doi/10.1073/pnas.1808274115
- 原作者公开仓库：https://www.research-collection.ethz.ch/handle/20.500.11850/284650
- 本复现仓库：已完成

## 仓库用途
本仓库为课程可复现性评估作业，用于：
1. 复现论文核心结论：更干燥的土壤条件 → 细菌细胞间接触与接合转移增加
2. 修复原仓库问题：无运行说明、无环境清单、参数硬编码、缺少绘图脚本
3. 提供可直接运行的简化代码与复现图表

## 仓库结构
├── README.md               # 说明文件
├── code/                   # 复现代码
│   ├── ibm_model_simple.m  # 个体基模型（MATLAB）
│   └── plot_reproduce.py   # 图表复现（Python）
├── data/                   # 模拟数据
├── results/                # 复现结果图表
└── docs/                   # 可复现性评估报告

## 运行环境
### MATLAB
- 版本：R2020b 及以上
- 工具箱：PDE Toolbox

### Python
- 版本：3.8+
- 依赖安装：
pip install pandas matplotlib numpy

## 复现步骤
1. 运行 code/ibm_model_simple.m 生成模拟数据
2. 运行 code/plot_reproduce.py 复现图表
3. 结果自动保存到 results/ 文件夹

## 复现结果
成功复现核心规律：
基质势越低（环境越干燥）→ 水相越破碎 → 细菌接触时间越长 → 接合率越高
与原文图3、图5趋势完全一致。